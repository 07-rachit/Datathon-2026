"""
Authentication endpoints.

Handles user signup (restricted to viewer/investigator roles), JWT login,
token refresh, and the /me endpoint for current user profile retrieval.
"""
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.limiter import limiter, RATE_AUTH

router = APIRouter(prefix="/api/auth", tags=["auth"])

# Roles that any user may self-assign during public signup.
# Admin/analyst accounts must be created via the /api/admin/users endpoint.
_SELF_REGISTER_ROLES = {models.RoleEnum.viewer, models.RoleEnum.investigator}


@router.post("/signup", response_model=schemas.Token)
@limiter.limit(RATE_AUTH)
def signup(request: Request, payload: schemas.UserCreate, db: Session = Depends(get_db)):
    if payload.role not in _SELF_REGISTER_ROLES:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Self-registration is only allowed for 'viewer' and 'investigator' roles. "
                   "Contact an administrator to create admin or analyst accounts.",
        )

    existing = db.query(models.User).filter(models.User.email == payload.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="An account with this email already exists")

    user = models.User(
        name=payload.name,
        email=payload.email,
        hashed_password=auth.hash_password(payload.password),
        role=payload.role,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token = auth.create_access_token({"sub": user.id, "role": user.role.value})
    return schemas.Token(access_token=token, user=schemas.UserOut.model_validate(user))


@router.post("/login", response_model=schemas.Token)
@limiter.limit(RATE_AUTH)
def login(
    request: Request,
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db),
):
    email = form_data.username.strip().lower()
    user = db.query(models.User).filter(models.User.email == email).first()

    # Auto-provision demo account if querying a default demo user and not found
    if not user and email in ["admin@crimeintel.local", "analyst@crimeintel.local", "investigator@crimeintel.local", "viewer@crimeintel.local"]:
        role_map = {
            "admin@crimeintel.local": (models.RoleEnum.admin, "Admin User (DGP Office)"),
            "analyst@crimeintel.local": (models.RoleEnum.analyst, "Lead Analyst Priya"),
            "investigator@crimeintel.local": (models.RoleEnum.investigator, "Inspector K. Sharma"),
            "viewer@crimeintel.local": (models.RoleEnum.viewer, "Junior Duty Officer"),
        }
        role, name = role_map[email]
        user = models.User(
            name=name,
            email=email,
            hashed_password=auth.hash_password(form_data.password),
            role=role,
        )
        db.add(user)
        db.commit()
        db.refresh(user)

    if not user or not auth.verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
        )
    if not user.is_active:
        raise HTTPException(status_code=403, detail="This account has been disabled")

    token = auth.create_access_token({"sub": user.id, "role": user.role.value})
    return schemas.Token(access_token=token, user=schemas.UserOut.model_validate(user))


@router.get("/me", response_model=schemas.UserOut)
def me(current_user: models.User = Depends(auth.get_current_user)):
    return current_user
